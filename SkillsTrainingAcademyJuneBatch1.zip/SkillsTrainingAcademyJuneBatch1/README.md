# Automated Artifact Versioning Pipeline

## Overview
A Flask API wired up with a full CI/CD pipeline using GitHub Actions.
Every push automatically tests, builds a Docker image, tags it with
the git commit SHA, and pushes it to Docker Hub.

## What's inside
SkillsTrainingAcademyJuneBatch1/
├── app.py
├── test_app.py
├── dockerfile
├── requirements.txt
├── nginx.html
├── reports/
│   └── pylint-report.txt
├── backups/
│   ├── calculator.yml
│   └── ci_old.yml
└── .github/workflows/
    └── ci.yml

## API Endpoints
| Endpoint | Method | Response |
|----------|--------|---------|
| `/` | GET | `Hello DevOps Students!` |
| `/health` | GET | `{"status": "UP"}` |
| `/userDetails` | GET | `{"name": "Riya Jamsutkar", "age": 21, ...}` |

## Tools Used
| Tool | Purpose |
|------|---------|
| Flask | Backend API |
| pytest | Unit testing |
| Docker | Containerising the app |
| Docker Hub | Image registry |
| GitHub Actions | CI/CD automation |

## How to Run

### Run locally
pip install -r requirements.txt
python app.py

### Run tests
pytest test_app.py

### Build and run with Docker
docker build -f dockerfile -t flask-ci-demo .
docker run -p 5000:5000 flask-ci-demo

## Triggering a versioned release
git tag v1.0.0
git push origin v1.0.0

## What I'd improve next
- Add more API endpoints with real data
- Add a database (PostgreSQL)
- Auto-generate changelog from commit messages
- Multi-platform Docker builds (amd64 + arm64)