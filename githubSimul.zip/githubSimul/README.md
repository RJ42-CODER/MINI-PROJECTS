# Git Workflow Simulator

## What is this?
A mini project where I simulated how a real dev team works on GitHub.
I set up a shared repo and pretended to be a 3-person team — branches,
pull requests, code reviews, merge conflicts, the whole thing.

## What I did
- Created a GitHub repo with **branch protection** on `main` (no direct pushes allowed)
- Made feature branches like a real team would
- Opened **Pull Requests** and did mock code reviews
- Deliberately caused a **merge conflict** and fixed it
- Tagged a **release** at the end
- Wrote a `CONTRIBUTING.md` explaining the whole workflow

## Why I built this
To understand how professional teams actually use Git day-to-day —
not just `git add`, `git commit`, `git push`, but the real collaboration flow.

## Skills practiced
`Git` `GitHub` `Branching` `PRs` `Docs`